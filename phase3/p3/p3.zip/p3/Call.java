package p3;

public class Call implements Instruction {

}
