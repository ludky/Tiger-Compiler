package p3;

public interface Instruction {
	
	public String toString();
}
