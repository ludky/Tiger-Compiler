package p3;

public class Callr implements Instruction {

}
